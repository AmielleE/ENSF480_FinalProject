package model;

public class Promotion {
    public void sendPromo(Customer c) {
        c.receivePromotion();
    }
}