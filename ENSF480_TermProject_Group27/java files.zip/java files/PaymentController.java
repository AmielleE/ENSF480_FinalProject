package controller;

import model.PaymentInfo;

//controlling the pay function

public class PaymentController {

    public boolean pay(PaymentInfo info) {
        System.out.println("Paying...");
        return true;
    }
}
